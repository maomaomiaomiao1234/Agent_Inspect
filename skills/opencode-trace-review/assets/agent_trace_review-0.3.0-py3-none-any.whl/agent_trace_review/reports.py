from defusedxml.ElementTree import fromstring

from .models import Evaluation, Run, Verification
from .util import canonical, digest


def junit_report(content: bytes, check_id: str, state_hash: str, suite_hash: str, phase="final") -> dict:
    if len(content) > 20 * 1024 * 1024:
        raise ValueError("JUnit 报告超过 20 MB。")
    try:
        root = fromstring(content)
    except Exception as exc:
        raise ValueError("无法解析安全的 JUnit XML。") from exc
    if root.tag not in {"testsuite", "testsuites"}:
        raise ValueError("JUnit 根节点必须为 testsuite 或 testsuites。")
    cases = {}
    for case in root.iter("testcase"):
        name = case.get("classname", "") + "::" + case.get("name", "unnamed")
        if name in cases:
            raise ValueError(f"JUnit 中用例 ID 重复，无法进行可靠回归比较：{name}")
        status = (
            "error"
            if case.find("error") is not None
            else "fail"
            if case.find("failure") is not None
            else "skipped"
            if case.find("skipped") is not None
            else "pass"
        )
        cases[name] = status
    passed = sum(v == "pass" for v in cases.values())
    failed = sum(v in {"fail", "error"} for v in cases.values())
    skipped = sum(v == "skipped" for v in cases.values())
    # A suite-level error must not be erased by successful child testcases.
    suites = list(root.iter("testsuite")) + ([root] if root.tag == "testsuites" else [])
    suite_errors = any(int(suite.get("errors", "0")) > 0 for suite in suites)
    suite_failures = any(int(suite.get("failures", "0")) > 0 for suite in suites)
    for suite in suites:
        if suite.get("tests") is not None and int(suite.get("tests")) != sum(
            1 for _ in suite.iter("testcase")
        ):
            raise ValueError("JUnit tests 计数与 testcase 集合不一致，无法确认完整执行。")
    result = (
        "error"
        if suite_errors or "error" in cases.values()
        else "fail"
        if failed or suite_failures
        else "pass"
        if passed
        else "unknown"
    )
    return Verification(
        id="junit_" + digest(content)[:16],
        check_id=check_id,
        provenance="external_verifier",
        result=result,
        phase=phase,
        state_hash=state_hash,
        suite_hash=suite_hash,
        executed=passed + failed,
        passed=passed,
        failed=failed,
        skipped=skipped,
        cases=cases,
        source_text=content.decode(),
    ).model_dump()


def markdown_report(run: Run, evaluation: Evaluation) -> str:
    lines = [
        f"# {run.title}",
        "",
        f"Run: `{run.id}` · Evaluation: `{evaluation.id}`",
        "",
        f"**结果：{evaluation.outcome}** — {evaluation.outcome_reason}",
        "",
        f"模型：{', '.join(run.models) or '未知'}",
        f"轨迹来源：{run.framework} · {'合成示例，不用于真实模型排名' if run.demo else '用户提供的运行记录'}",
        (
            f"任务规则：{evaluation.custom['profile']['id']} · {evaluation.custom['profile_hash']}"
            if evaluation.custom
            else "任务规则：未提供自定义 Profile"
        ),
        "",
        "## 指标",
        "",
        "| 指标 | 数值 | 证据状态 |",
        "| --- | --- | --- |",
    ]
    for metric in evaluation.metrics:
        lines.append(
            f"| {metric.label} | {metric.value if metric.value is not None else '未知'} {metric.unit} | {metric.status} |"
        )
    lines += ["", "## 诊断", ""]
    if not evaluation.findings:
        lines += ["在已观察的范围内，没有触发当前规则。此结果不等于证明没有问题。", ""]
    for finding in evaluation.findings:
        lines += [
            f"### {finding.title} [{finding.verdict}]",
            "",
            finding.explanation,
            "",
            "证据：" + ", ".join(f"`{r}`" for r in finding.evidence_ids),
            "",
            "限制：" + "；".join(finding.limitations),
            "",
            finding.recommendation,
            "",
        ]
    lines += ["## 证据索引", ""]
    for evidence in evaluation.evidence:
        lines.append(
            f"- `{evidence.id}`: {evidence.description} · {evidence.pointer or evidence.kind} · artifact `{evidence.artifact_id or 'derived'}`"
        )
    lines += ["", "## 观察范围", ""]
    if evaluation.judge and evaluation.judge.get("backend") == "chat-completions":
        lines += [
            f"评审模型：{evaluation.judge['model']}；模型判断不等于独立事实核验。",
            f"评审用量（与被评 Agent 分开）：{canonical(evaluation.judge.get('usage'))}；费用未知。",
            "",
        ]
    lines += [f"- {key}: {value['level']} — {value['reason']}" for key, value in run.coverage.items()]
    lines += ["", "此报告分析已有导出材料；没有执行轨迹中的命令。", ""]
    return "\n".join(lines)
