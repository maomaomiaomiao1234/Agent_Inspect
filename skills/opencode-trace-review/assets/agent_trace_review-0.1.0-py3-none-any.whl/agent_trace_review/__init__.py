"""OpenCode trajectory evaluation, with explicit evidence and uncertainty."""

__version__ = "0.1.0"
