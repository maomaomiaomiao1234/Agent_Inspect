from .analysis import analyze
from .opencode import import_data
from .storage import Store


def ingest(store: Store, content: bytes, **kwargs):
    run, created = import_data(store, content, **kwargs)
    try:
        evaluation = store.get_evaluation(run.id)
    except KeyError:
        evaluation = analyze(run)
        store.save_evaluation(evaluation)
    return run, evaluation, created
