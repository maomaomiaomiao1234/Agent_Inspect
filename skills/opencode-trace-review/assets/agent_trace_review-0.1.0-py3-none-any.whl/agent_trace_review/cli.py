import json
import subprocess
from pathlib import Path

import typer

from .analysis import compare
from .demo import demo_bundles
from .judge import judge_run
from .models import Evaluation, Run
from .reports import markdown_report
from .service import ingest
from .storage import Store
from .util import canonical

app = typer.Typer(no_args_is_help=True, help="OpenCode 本地轨迹分析与评估。导入过程不执行日志中的命令。")


@app.command("import")
def import_file(
    file: Path,
    data_dir: Path = Path(".agent-review"),
    task: Path | None = None,
    diff: Path | None = None,
    agent_version: str | None = None,
    first_message: str | None = None,
    last_message: str | None = None,
):
    try:
        run, evaluation, created = ingest(
            Store(data_dir),
            file.read_bytes(),
            filename=file.name,
            task=json.loads(task.read_text()) if task else None,
            diff=diff.read_text() if diff else None,
            agent_version=agent_version,
            first_message=first_message,
            last_message=last_message,
        )
        typer.echo(canonical({"run_id": run.id, "created": created, "outcome": evaluation.outcome}))
    except (ValueError, OSError) as exc:
        raise typer.BadParameter(str(exc)) from exc


@app.command("import-session")
def import_session(session_id: str, data_dir: Path = Path(".agent-review"), task: Path | None = None):
    """调用本机 opencode export 导入指定会话；不会启动模型。"""
    if not session_id.startswith("ses_") or not all(c.isalnum() or c == "_" for c in session_id):
        raise typer.BadParameter("需要有效的 OpenCode session ID。")
    try:
        result = subprocess.run(["opencode", "export", session_id, "--pure"], capture_output=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise typer.BadParameter(
            "无法运行 opencode export；请确认已安装 OpenCode 且命令在 PATH 中，或手动导入导出文件。"
        ) from exc
    if result.returncode:
        raise typer.BadParameter(result.stderr.decode(errors="replace"))
    run, evaluation, created = ingest(
        Store(data_dir), result.stdout, task=json.loads(task.read_text()) if task else None
    )
    typer.echo(canonical({"run_id": run.id, "created": created, "outcome": evaluation.outcome}))


@app.command()
def demo(data_dir: Path = Path(".agent-review")):
    """导入两条明确标记为合成的示例轨迹。"""
    store = Store(data_dir)
    for bundle in demo_bundles():
        run, evaluation, _ = ingest(store, canonical(bundle).encode())
        typer.echo(f"{run.id}  {evaluation.outcome:12}  {run.title} [合成示例]")


@app.command("list")
def list_runs(data_dir: Path = Path(".agent-review")):
    for run in Store(data_dir).list_runs():
        typer.echo(f"{run['id']}  {run['outcome']:12}  {run['title']}")


@app.command()
def report(
    run_id: str, data_dir: Path = Path(".agent-review"), format: str = "markdown", output: Path | None = None
):
    store = Store(data_dir)
    run, evaluation = store.get_run(run_id), store.get_evaluation(run_id)
    if format == "markdown":
        content = markdown_report(run, evaluation)
    elif format == "bundle":
        content = canonical(store.bundle(run_id))
    elif format == "json":
        content = canonical({"run": run.model_dump(), "evaluation": evaluation.model_dump()})
    else:
        raise typer.BadParameter("format: markdown / json / bundle")
    if output:
        output.write_text(content)
    else:
        typer.echo(content)


@app.command("compare")
def compare_runs(left: str, right: str, data_dir: Path = Path(".agent-review")):
    store = Store(data_dir)
    typer.echo(
        canonical(
            compare(
                store.get_run(left),
                store.get_run(right),
                store.get_evaluation(left),
                store.get_evaluation(right),
            )
        )
    )


@app.command()
def judge(run_id: str, data_dir: Path = Path(".agent-review")):
    """发送限定的可见轨迹到已配置的 Judge 模型；可能产生 API 费用。"""
    store = Store(data_dir)
    try:
        evaluation = judge_run(store, store.get_run(run_id))
        typer.echo(canonical({"revision_id": evaluation.id, "judge": evaluation.judge}))
    except (ValueError, KeyError) as exc:
        raise typer.BadParameter(str(exc)) from exc
    except Exception as exc:
        raise typer.BadParameter(f"Judge 调用失败（{type(exc).__name__}），原评估保留。") from exc


@app.command()
def schema(output: Path | None = None):
    content = canonical({"run": Run.model_json_schema(), "evaluation": Evaluation.model_json_schema()})
    output.write_text(content) if output else typer.echo(content)


@app.command()
def serve(data_dir: Path = Path(".agent-review"), port: int = 8765):
    import uvicorn

    from .api import create_app

    uvicorn.run(create_app(str(data_dir)), host="127.0.0.1", port=port)


if __name__ == "__main__":
    app()
